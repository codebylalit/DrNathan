export interface Video {
  id: string;
  title: string;
  duration: string;
  views: string;
  thumbnailUrl: string;
  videoUrl: string; // instagram/tiktok link
  category: string;
  highYieldFact: string;
  publishedDate: string;
}

export interface LeadMagnet {
  id: string;
  title: string;
  description: string;
  chapters: string[];
  downloadName: string;
  badge: string;
}

export interface NewsletterSubmission {
  id: string;
  name: string;
  email: string;
  leadMagnetId: string;
  submittedAt: string;
}

export interface CollaborationInquiry {
  id: string;
  name: string;
  email: string;
  organization: string;
  inquiryType: 'brand_partnership' | 'speaking_engagement' | 'media_press' | 'other';
  message: string;
  submittedAt: string;
}

export interface BioLink {
  id: string;
  title: string;
  description: string;
  url: string;
  isExternal: boolean;
  category: string;
  badge?: string;
  iconName: string;
}

export interface PressMention {
  id: string;
  outlet: string;
  logoType: 'text' | 'svg';
  textLogo?: string;
  logoColor?: string;
  quote: string;
  articleUrl: string;
}

import { Video, LeadMagnet, PressMention, BioLink } from './types';

export const VIDEO_PILLARS = [
  { id: 'all', name: 'All Insights' },
  { id: 'nutrition', name: 'Nutrition & Metabolic' },
  { id: 'cardiovascular', name: 'Cardiovascular Health' },
  { id: 'preventive', name: 'Preventive Care' },
  { id: 'longevity', name: 'Longevity & Sleep' }
];

export const VIDEOS: Video[] = [
  {
    id: 'vid-meal-timing',
    title: 'How Circadian Meal Timing Drastically Alters Insulin Response',
    duration: '0:58',
    views: '1.2M',
    thumbnailUrl: 'https://images.unsplash.com/photo-1498837167922-ddd27525d352?auto=format&fit=crop&w=600&q=80',
    videoUrl: 'https://instagram.com/drnathonsmith',
    category: 'nutrition',
    highYieldFact: 'Eating late shifts your melatonin receptors, making you temporarily glucose intolerant. Finish dinners by 7 PM.',
    publishedDate: '2 Days ago'
  },
  {
    id: 'vid-hypertension-silent',
    title: 'The Silent Killer: How to Audit Your Authentic Blood Pressure',
    duration: '1:05',
    views: '840K',
    thumbnailUrl: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=600&q=80',
    videoUrl: 'https://instagram.com/drnathonsmith',
    category: 'cardiovascular',
    highYieldFact: 'Taking BP with an active bladder, legs crossed, or back unsupported can falsely spike readings by 5-15 mmHg.',
    publishedDate: '5 Days ago'
  },
  {
    id: 'vid-3-blood-tests',
    title: 'The 3 Standard Blood Tests You Should Request Yearly (Beyond CBC)',
    duration: '1:12',
    views: '2.1M',
    thumbnailUrl: 'https://images.unsplash.com/photo-1579154204601-01588f351167?auto=format&fit=crop&w=600&q=80',
    videoUrl: 'https://instagram.com/drnathonsmith',
    category: 'preventive',
    highYieldFact: 'Request ApoB (better than LDL-C), fasting insulin (screens metabolic dysfunction before HbA1c spikes), and hs-CRP.',
    publishedDate: '1 Week ago'
  },
  {
    id: 'vid-zone2-cardio',
    title: 'Why Zone 2 Cardio Rebuilds Mitochondria Faster Than HIIT',
    duration: '0:45',
    views: '1.5M',
    thumbnailUrl: 'https://images.unsplash.com/photo-1476480862126-209bfaa8edc8?auto=format&fit=crop&w=600&q=80',
    videoUrl: 'https://instagram.com/drnathonsmith',
    category: 'longevity',
    highYieldFact: 'Zone 2 cardio forces cells to burn fat exclusively, increasing mitochondrial efficiency. Aim for 150 mins per week.',
    publishedDate: '2 Weeks ago'
  },
  {
    id: 'vid-sleep-hygiene',
    title: 'Deep Sleep Optimization: The "10-3-2-1-0" Clinical Framework',
    duration: '1:15',
    views: '3.4M',
    thumbnailUrl: 'https://images.unsplash.com/photo-1511295742364-92767fc68d8a?auto=format&fit=crop&w=600&q=80',
    videoUrl: 'https://instagram.com/drnathonsmith',
    category: 'longevity',
    highYieldFact: 'No caffeine inside 10h, no food inside 3h, no work inside 2h, no screens inside 1h, and 0 alarms hitting snooze.',
    publishedDate: '3 Weeks ago'
  },
  {
    id: 'vid-salt-potassium',
    title: 'Forget Sodium Alone: It’s the Sodium-to-Potassium Ratio That Rules BP',
    duration: '0:56',
    views: '920K',
    thumbnailUrl: 'https://images.unsplash.com/photo-1518085114588-258207c91585?auto=format&fit=crop&w=600&q=80',
    videoUrl: 'https://instagram.com/drnathonsmith',
    category: 'cardiovascular',
    highYieldFact: 'Potassium flushes sodium out through urine. Increasing dietary potassium from avocados/greens often drops BP better than cutting salt.',
    publishedDate: '1 Month ago'
  },
  {
    id: 'vid-fasting-metabolics',
    title: 'Intermittent Fasting: Weight Loss Magic or Just Calorie Restriction?',
    duration: '1:02',
    views: '1.7M',
    thumbnailUrl: 'https://images.unsplash.com/photo-1490818383965-f24b52cbf1a5?auto=format&fit=crop&w=600&q=80',
    videoUrl: 'https://instagram.com/drnathonsmith',
    category: 'nutrition',
    highYieldFact: 'IF matches standard calorie reduction for weight, but offers unique therapeutic perks in autophagy and gut microbiome resting time.',
    publishedDate: '1 Month ago'
  },
  {
    id: 'vid-magnesium-deficiency',
    title: 'The 3 Forms of Magnesium You Need—And Which to Avoid entirely',
    duration: '0:59',
    views: '2.8M',
    thumbnailUrl: 'https://images.unsplash.com/photo-1540340061720-ee2c4856e99c?auto=format&fit=crop&w=600&q=80',
    videoUrl: 'https://instagram.com/drnathonsmith',
    category: 'preventive',
    highYieldFact: 'Use Glycinate for sleep/anxiety, L-Threonate for cognitive focus/brain barrier passage, and avoid cheap Magnesium Oxide (low absorption).',
    publishedDate: '1 Month ago'
  }
];

export const LEAD_MAGNETS: LeadMagnet[] = [
  {
    id: 'blueprint-longevity',
    title: 'The High-Yield Longevity Protocol',
    description: 'A clinical checklist for optimizing metabolic health, sleep architecture, and cardiorespiratory fitness based on Harvard-Stanford medical principles.',
    downloadName: 'dr_nathon_smith_longevity_protocol.pdf',
    badge: 'Popular',
    chapters: [
      'Chapter 1: The Bioenergetics of Longevity - Zone 2 & VO2 Max Standards',
      'Chapter 2: Circadian Alignments - Dynamic Meal Schedulers',
      'Chapter 3: Sleep Architecture - Chronobiology Protocols & Magnesium Guidelines',
      'Chapter 4: Yearly Biomarker Audits - Full Lab Interpretation Checklist'
    ]
  },
  {
    id: 'guide-hypertension',
    title: 'Evidence-Based Blood Pressure Blueprint',
    description: 'Beyond "just stop consuming salt." Discover the clinical methods to naturally buffer vascular stiffness and optimize your sodium-potassium ratio.',
    downloadName: 'dr_nathon_smith_hypertension_blueprint.pdf',
    badge: 'Hypertension',
    chapters: [
      'Chapter 1: Pathophysiology of Essential Hypertension - Plain English Breakdown',
      'Chapter 2: The Sodium-Potassium Ratio - Meal Formulas for Nitric Oxide Release',
      'Chapter 3: Accurate BP Audits - How to Prevent "White Coat Syndrome" Spike',
      'Chapter 4: Clinically Documented Breathing Cycles for Instant Arterial Calming'
    ]
  },
  {
    id: 'checklist-nutrition',
    title: 'Circadian Nutrition & Insulin Sensitivity Framework',
    description: 'Learn the precise timing parameters to schedule carbs, fats, and proteins for peak cortisol alignment and zero afternoon energy dips.',
    downloadName: 'dr_nathon_smith_circadian_nutrition.pdf',
    badge: 'Metabolic',
    chapters: [
      'Chapter 1: The Circadian clock of your Pancreas - Why Sunrise Matters',
      'Chapter 2: Pre-meal Fiber Sequencing - Flatlining Glycemic Spikes',
      'Chapter 3: Late-Night Melatonin & Insulin Clashes',
      'Chapter 4: Fasting Mimicking Windows - Cellular Rest Demystified'
    ]
  }
];

export const PRESS_MENTIONS: PressMention[] = [
  {
    id: 'press-harvard',
    outlet: 'Harvard Crimson Digest',
    logoType: 'text',
    textLogo: 'The Harvard Crimson',
    logoColor: 'text-[#A51C30]', // Harvard Crimson Red
    quote: "Dr. Smith represents a new breed of clinicians translating high-level medical journals into practical daily directives for the social media generation.",
    articleUrl: '#'
  },
  {
    id: 'press-stanford',
    outlet: 'Stanford Med Scope',
    logoType: 'text',
    textLogo: 'Stanford Medicine',
    logoColor: 'text-[#8C1515]', // Stanford Red
    quote: "Democratizing medical knowledge is a key component of future preventative public health. Resident Nathon Smith shows exactly how to bridge that gap.",
    articleUrl: '#'
  },
  {
    id: 'press-npr',
    outlet: 'NPR health',
    logoType: 'text',
    textLogo: 'npr health',
    logoColor: 'text-[#2D74DA]',
    quote: "Simple, visual, and strictly evidence-backed. Smith’s breakdown of insomnia and circadian meal-timing has successfully replaced generic wellness gossip.",
    articleUrl: '#'
  },
  {
    id: 'press-menshealth',
    outlet: 'Men’s Health',
    logoType: 'text',
    textLogo: 'Men’s Health',
    logoColor: 'text-white font-black tracking-tighter italic uppercase text-lg',
    quote: "His high-yield metrics are changing how people view their biometric workups. He separates performance gimmicks from actual medical science.",
    articleUrl: '#'
  }
];

export const BIO_LINKS: BioLink[] = [
  {
    id: 'link-youtube',
    title: 'Subscribe on YouTube',
    description: 'Weekly deep-dives explaining chronic diseases and longevity science with fully referenced slides.',
    url: 'https://youtube.com',
    isExternal: true,
    category: 'social',
    badge: '120K Subs',
    iconName: 'youtube'
  },
  {
    id: 'link-instagram',
    title: 'Follow on Instagram',
    description: 'Daily high-yield medical Reels, Q&A stories, and slides debunking mainstream wellness myths.',
    url: 'https://instagram.com/drnathonsmith',
    isExternal: true,
    category: 'social',
    badge: '950K Fans',
    iconName: 'instagram'
  },
  {
    id: 'link-tiktok',
    title: 'Follow on TikTok',
    description: 'Fast, engaging 60-second breakdowns of healthy foods, hypertension hacks, and fitness truths.',
    url: 'https://tiktok.com',
    isExternal: true,
    category: 'social',
    badge: '480K Followers',
    iconName: 'video'
  },
  {
    id: 'link-research',
    title: 'Stanford Cohort Metabolic Study (2025)',
    description: 'Read Nathon’s published research investigating continuous glucose monitor readings in non-diabetic adults.',
    url: 'https://pubmed.ncbi.nlm.nih.gov',
    isExternal: true,
    category: 'academic',
    badge: 'Published Paper',
    iconName: 'file-text'
  },
  {
    id: 'link-mediakit',
    title: 'Speaking & Brand Media Kit',
    description: 'Download Dr. Nathon’s audience statistics, past keynotes, and technical capabilities for brand integrations.',
    url: '#collaborate',
    isExternal: false,
    category: 'business',
    badge: 'Press PDF',
    iconName: 'download'
  }
];

// Initial preloaded list entries for demo creator dashboard (adds realism and keeps forms exciting)
export const PRELOADED_SUBSCRIBERS = [
  { id: 'sub-1', name: 'Laura Vance', email: 'laura.vance@gmail.com', leadMagnetId: 'blueprint-longevity', submittedAt: '2026-06-18 14:24' },
  { id: 'sub-2', name: 'David Kim', email: 'dkim@stanford.edu', leadMagnetId: 'guide-hypertension', submittedAt: '2026-06-18 19:10' },
  { id: 'sub-3', name: 'Marcus Sterling', email: 'marcus.sterling@outlook.com', leadMagnetId: 'blueprint-longevity', submittedAt: '2026-06-19 01:45' }
];

export const PRELOADED_INQUIRIES = [
  {
    id: 'inq-1',
    name: 'Sarah Jenkins',
    email: 'sjenkins@athleticgreens.com',
    organization: 'AG1 Wellness',
    inquiryType: 'brand_partnership',
    message: 'Hello Dr. Smith, we love your rigorous academic breakdown of micronutrients! We would love to discuss a sponsored series on Instagram and YouTube focusing on trace minerals and nitric oxide pathways.',
    submittedAt: '2026-06-18 09:12'
  },
  {
    id: 'inq-2',
    name: 'Dr. Arthur Pendelton',
    email: 'pendelton.a@longevity-summit.org',
    organization: 'Annual Prevention & Longevity Summit',
    inquiryType: 'speaking_engagement',
    message: 'We are organizing the keynotes for the Oct 2026 Summit in San Francisco. Given your residency scope and background at Harvard/Stanford, we believe your voice would be pristine for our "Public Health in the Social Age Panel". Please let us know your availability.',
    submittedAt: '2026-06-18 16:35'
  }
];

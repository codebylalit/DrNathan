import React, { useState, useEffect } from 'react';
import {
  Stethoscope,
  Award,
  Instagram,
  Youtube,
  Mail,
  ArrowUp,
  ExternalLink,
  ShieldAlert,
  Sliders,
  Sparkles,
  Play,
  Briefcase
} from 'lucide-react';
import Header from './components/Header';
import Hero from './components/Hero';
import CredibilityBar from './components/CredibilityBar';
import ContentGrid from './components/ContentGrid';
import About from './components/About';
import LinkHub from './components/LinkHub';
import NewsletterSection from './components/NewsletterSection';
import ContactForm from './components/ContactForm';
import Dashboard from './components/Dashboard';

import { PRELOADED_SUBSCRIBERS, PRELOADED_INQUIRIES } from './data';
import { NewsletterSubmission, CollaborationInquiry } from './types';

export default function App() {
  const [showDashboard, setShowDashboard] = useState(false);
  const [subscribers, setSubscribers] = useState<NewsletterSubmission[]>([]);
  const [inquiries, setInquiries] = useState<CollaborationInquiry[]>([]);
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [copiedEmail, setCopiedEmail] = useState(false);

  // Load from local storage or preloaded data sets
  useEffect(() => {
    const cachedSubs = localStorage.getItem('nathon_subscribers_v2');
    if (cachedSubs) {
      setSubscribers(JSON.parse(cachedSubs));
    } else {
      setSubscribers(PRELOADED_SUBSCRIBERS);
      localStorage.setItem('nathon_subscribers_v2', JSON.stringify(PRELOADED_SUBSCRIBERS));
    }

    const cachedInqs = localStorage.getItem('nathon_inquiries_v2');
    if (cachedInqs) {
      setInquiries(JSON.parse(cachedInqs));
    } else {
      setInquiries(PRELOADED_INQUIRIES);
      localStorage.setItem('nathon_inquiries_v2', JSON.stringify(PRELOADED_INQUIRIES));
    }

    // Scroll listener for scrolling back to top button
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 500);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNewsletterSignup = (email: string, name: string, leadMagnetId: string) => {
    const newSub: NewsletterSubmission = {
      id: `sub-${Date.now()}`,
      name,
      email,
      leadMagnetId,
      submittedAt: new Date().toISOString().replace('T', ' ').substring(0, 16)
    };
    const updated = [newSub, ...subscribers];
    setSubscribers(updated);
    localStorage.setItem('nathon_subscribers_v2', JSON.stringify(updated));
  };

  const handleInquirySubmit = (inquiry: Omit<CollaborationInquiry, 'id' | 'submittedAt'>) => {
    const newInq: CollaborationInquiry = {
      ...inquiry,
      id: `inq-${Date.now()}`,
      submittedAt: new Date().toISOString().replace('T', ' ').substring(0, 16)
    };
    const updated = [newInq, ...inquiries];
    setInquiries(updated);
    localStorage.setItem('nathon_inquiries_v2', JSON.stringify(updated));
  };

  const handleDeleteSubscriber = (id: string) => {
    const updated = subscribers.filter((s) => s.id !== id);
    setSubscribers(updated);
    localStorage.setItem('nathon_subscribers_v2', JSON.stringify(updated));
  };

  const handleDeleteInquiry = (id: string) => {
    const updated = inquiries.filter((i) => i.id !== id);
    setInquiries(updated);
    localStorage.setItem('nathon_inquiries_v2', JSON.stringify(updated));
  };

  const scrollToSection = (sectionId: string) => {
    // If dashboard is open, close it first so scroll destinations exist in DOM
    setShowDashboard(false);
    
    setTimeout(() => {
      const element = document.getElementById(sectionId);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }, 100);
  };

  const handleCopyEmail = () => {
    navigator.clipboard.writeText('partnership@drnathonsmith.com');
    setCopiedEmail(true);
    setTimeout(() => setCopiedEmail(false), 2000);
  };

  return (
    <div className="bg-[#0E0E12] min-h-screen flex flex-col font-sans select-none selection:bg-[#5865F2] selection:text-white relative overflow-x-hidden">
      
      {/* Background Decorative Blur Blobs representing the "Frosted Glass" Theme */}
      <div className="absolute top-[-100px] right-[-100px] w-[500px] h-[500px] bg-[#5865F2] rounded-full blur-[130px] opacity-15 pointer-events-none z-0"></div>
      <div className="absolute bottom-[20%] left-[-100px] w-[400px] h-[400px] bg-[#8FB3E0] rounded-full blur-[120px] opacity-10 pointer-events-none z-0"></div>
      <div className="absolute top-[40%] right-[-150px] w-[500px] h-[500px] bg-[#5865F2] rounded-full blur-[140px] opacity-10 pointer-events-none z-0"></div>
      <div className="absolute bottom-[5%] left-[10%] w-[450px] h-[450px] bg-[#8FB3E0] rounded-full blur-[130px] opacity-10 pointer-events-none z-0"></div>

      {/* Sticky Navigation Header */}
      <div className="relative z-10 w-full">
        <Header
          showDashboard={showDashboard}
          onToggleDashboard={() => {
            setShowDashboard(!showDashboard);
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          subscriberCount={subscribers.length}
          inquiryCount={inquiries.length}
        />
      </div>

      {/* Primary Workspace View */}
      <main className="flex-grow relative z-10">
        {showDashboard ? (
          /* Back Office Creator Dashboard */
          <Dashboard
            subscribers={subscribers}
            inquiries={inquiries}
            onDeleteSubscriber={handleDeleteSubscriber}
            onDeleteInquiry={handleDeleteInquiry}
            onClose={() => setShowDashboard(false)}
          />
        ) : (
          /* Main Personal Brand Site Content */
          <>
            <Hero
              onNewsletterSignup={handleNewsletterSignup}
              onScrollToSection={scrollToSection}
            />
            
            <CredibilityBar />
            
            <ContentGrid />
            
            <About />
            
            <LinkHub />
            
            <NewsletterSection onNewsletterSignup={handleNewsletterSignup} />
            
            <ContactForm onInquirySubmit={handleInquirySubmit} />
          </>
        )}
      </main>

      {/* Floating back-to-top and Quick Dashboard notification triggers */}
      <div className="fixed bottom-6 right-6 z-30 flex flex-col space-y-3">
        {/* Scroll To Top button */}
        {showScrollTop && (
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="p-3 bg-gray-900 border border-gray-800 text-gray-300 hover:text-white hover:border-[#5865F2] rounded-full shadow-2xl transition-all hover:-translate-y-0.5 cursor-pointer"
            title="Scroll to Top"
          >
            <ArrowUp className="h-5 w-5" />
          </button>
        )}
      </div>

      {/* Sticky Banner notifying visitor about the Portal */}
      {!showDashboard && (
        <div className="bg-gradient-to-r from-gray-900 via-[#16161F] to-gray-900 border-t border-gray-850 py-3.5 px-4 text-center text-xs text-gray-400">
          <div className="max-w-4xl mx-auto flex flex-col sm:flex-row items-center justify-center gap-3">
            <span className="flex items-center space-x-1 text-[#8FB3E0]">
              <Sparkles className="h-4 w-4 text-amber-400 animate-pulse" />
              <strong>Sandbox Mode:</strong>
            </span>
            <span>
              Sign up for the newsletter or submit a partnership proposal to see them logged instantly inside <strong>Dr. Smith’s Creator Portal</strong> on top!
            </span>
            <button
              onClick={() => {
                setShowDashboard(true);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="text-[#5865F2] hover:text-white underline font-semibold cursor-pointer"
            >
              Open Creator Portal &rarr;
            </button>
          </div>
        </div>
      )}

      {/* Footer Block */}
      <footer className="bg-[#0A0A0D] border-t border-gray-900 py-12 text-left">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
            
            {/* Box 1: Brand Info */}
            <div className="md:col-span-4 space-y-3">
              <div className="flex items-center space-x-2">
                <Stethoscope className="h-5 w-5 text-[#5865F2]" />
                <span className="font-display font-bold text-lg text-white">Dr. Nathon Smith, MD</span>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed">
                Bridging the gap between high-level medical journals and clean, evidence-based lifestyle changes for the clinical and digital age.
              </p>
              <div className="flex space-x-3 pt-1">
                <a href="https://instagram.com/drnathonsmith" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors" title="Instagram Profile">
                  <Instagram className="h-4.5 w-4.5" />
                </a>
                <a href="https://youtube.com" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors" title="YouTube Classroom">
                  <Youtube className="h-4.5 w-4.5" />
                </a>
                <a href="#newsletter" className="text-gray-400 hover:text-white transition-colors" title="Academic Newsletter">
                  <Mail className="h-4.5 w-4.5" />
                </a>
              </div>
            </div>

            {/* Box 2: Quick anchor redirects */}
            <div className="md:col-span-4 flex flex-col space-y-2">
              <span className="text-[10px] uppercase font-mono tracking-wider font-bold text-[#8FB3E0]">Primary Resources</span>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <a href="#content-insights" onClick={(e) => { e.preventDefault(); scrollToSection('content-insights'); }} className="text-gray-400 hover:text-[#5865F2] transition-colors">Latest Reels</a>
                <a href="#about-story" onClick={(e) => { e.preventDefault(); scrollToSection('about-story'); }} className="text-gray-400 hover:text-[#5865F2] transition-colors">Our Story</a>
                <a href="#link-hub" onClick={(e) => { e.preventDefault(); scrollToSection('link-hub'); }} className="text-gray-400 hover:text-[#5865F2] transition-colors">Start Resources</a>
                <a href="#newsletter" onClick={(e) => { e.preventDefault(); scrollToSection('newsletter'); }} className="text-gray-400 hover:text-[#5865F2] transition-colors">Free Blueprints</a>
                <a href="#collaborate" onClick={(e) => { e.preventDefault(); scrollToSection('collaborate'); }} className="text-gray-400 hover:text-[#5865F2] transition-colors">Brand Proposal</a>
                <button
                  onClick={() => { setShowDashboard(true); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="text-left text-[#8FB3E0] hover:text-white transition-colors text-xs font-semibold cursor-pointer"
                >
                  Admin Portal &bull; Live
                </button>
              </div>
            </div>

            {/* Box 3: Technical disclaimer & direct email fallback */}
            <div className="md:col-span-4 space-y-3">
              <span className="text-[10px] uppercase font-mono tracking-wider font-bold text-[#8FB3E0]">General Inquiries</span>
              <p className="text-[11px] text-gray-500 leading-normal">
                Dr. Nathon Smith’s materials represent clinical research reviews for public literacy. None of the content represents direct individual medical diagnostic advice.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-2">
                <button
                  onClick={handleCopyEmail}
                  className="bg-gray-900 hover:bg-gray-800 border border-gray-850 px-4 py-2 rounded-xl text-xs text-gray-300 font-medium transition-all cursor-pointer whitespace-nowrap active:scale-95"
                >
                  {copiedEmail ? 'Copied to Clipboard!' : 'Copy Partner Email'}
                </button>
                <a
                  href="#collaborate"
                  onClick={(e) => { e.preventDefault(); scrollToSection('collaborate'); }}
                  className="bg-[#5865F2] hover:bg-[#4d5add] text-white text-xs font-bold px-4 py-2 rounded-xl text-center flex items-center justify-center space-x-1"
                >
                  <span>Submit Inquiry</span>
                </a>
              </div>
            </div>

          </div>

          <div className="mt-8 pt-8 border-t border-gray-900 flex flex-col sm:flex-row items-center justify-between text-[10px] text-gray-500 font-mono gap-4">
            <span>&copy; {new Date().getFullYear()} Dr. Nathon Smith. All Rights Vetted.</span>
            <span className="flex items-center space-x-1">
              <span>Harvard Crimson</span>
              <span>&bull;</span>
              <span>Stanford Med Scholar Network</span>
            </span>
          </div>
        </div>
      </footer>

    </div>
  );
}

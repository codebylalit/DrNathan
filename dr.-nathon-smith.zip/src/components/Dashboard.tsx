import React, { useState } from 'react';
import { Database, Mail, Users, FileSpreadsheet, Inbox, Trash2, ArrowRightLeft, Sparkles, SlidersHorizontal, CheckCheck, Send, BarChart3, TrendingUp, ArrowDown } from 'lucide-react';
import { NewsletterSubmission, CollaborationInquiry } from '../types';
import { LEAD_MAGNETS, PRELOADED_SUBSCRIBERS } from '../data';

interface DashboardProps {
  subscribers: NewsletterSubmission[];
  inquiries: CollaborationInquiry[];
  onDeleteSubscriber: (id: string) => void;
  onDeleteInquiry: (id: string) => void;
  onClose: () => void;
}

export default function Dashboard({
  subscribers,
  inquiries,
  onDeleteSubscriber,
  onDeleteInquiry,
  onClose
}: DashboardProps) {
  const [activeTab, setActiveTab] = useState<'subscribers' | 'inquiries'>('inquiries');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedInquiryId, setSelectedInquiryId] = useState<string | null>(null);
  const [sentReply, setSentReply] = useState<string | null>(null);
  const [replyText, setReplyText] = useState('');

  const filteredSubs = subscribers.filter(
    (s) =>
      s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredInqs = inquiries.filter(
    (i) =>
      i.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      i.organization.toLowerCase().includes(searchTerm.toLowerCase()) ||
      i.message.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSendReply = (inqId: string) => {
    if (!replyText.trim()) return;
    setSentReply(inqId);
    setReplyText('');
    setTimeout(() => {
      setSentReply(null);
    }, 3000);
  };

  const getMagnetTitle = (id: string) => {
    return LEAD_MAGNETS.find((m) => m.id === id)?.title || 'Longevity Protocol';
  };

  return (
    <div className="bg-[#0E0E12] min-h-[85vh] text-left border-y border-emerald-500/20 relative py-12">
      {/* Background neon elements */}
      <div className="absolute top-10 left-10 w-[300px] h-[300px] bg-emerald-500/10 blur-[90px] rounded-full pointer-events-none"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* Dashboard Title Ribbon */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 border-b border-gray-850 pb-6">
          <div className="space-y-1">
            <div className="inline-flex items-center space-x-2 text-emerald-400 font-mono text-xs bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
              <Database className="h-3.5 w-3.5" />
              <span>Nathon Smith Creator Admin Core &bull; Secure Client Sync</span>
            </div>
            <h1 className="font-display font-black text-2xl sm:text-3xl text-white tracking-tight">
              Creator Back-Office Dashboard
            </h1>
            <p className="text-gray-400 text-xs">
              Review and manage lead magnets, organic newsletter signups, and business proposals flowing from social bio links.
            </p>
          </div>

          <div className="flex items-center space-x-3">
            <button
              onClick={onClose}
              className="px-4 py-2 bg-gray-900 border border-gray-800 text-xs font-semibold text-gray-300 hover:text-white rounded-xl transition-all cursor-pointer"
            >
              Exit Dashboard
            </button>
            <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" title="System synchronizer active"></span>
            <span className="text-xs text-gray-400 font-mono">Live Sync Engine</span>
          </div>
        </div>

        {/* Dynamic Key Performance Metrics Row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          
          <div className="bg-[#16161F] border border-gray-800 p-5 rounded-2xl relative overflow-hidden">
            <div className="absolute top-4 right-4 text-emerald-400 p-2 bg-emerald-500/10 rounded-lg">
              <Users className="h-5 w-5" />
            </div>
            <p className="text-[10px] font-mono uppercase text-gray-400 tracking-wider">Active Subscribers</p>
            <h3 className="font-display font-black text-3xl text-white mt-2">
              {80340 + subscribers.length}
            </h3>
            <div className="flex items-center space-x-1.5 text-[11px] text-emerald-400 mt-2 font-mono">
              <TrendingUp className="h-3.5 w-3.5" />
              <span>+{subscribers.length - 3 >= 0 ? subscribers.length - 3 : 0} today</span>
            </div>
          </div>

          <div className="bg-[#16161F] border border-gray-800 p-5 rounded-2xl relative overflow-hidden">
            <div className="absolute top-4 right-4 text-[#5865F2] p-2 bg-[#5865F2]/10 rounded-lg">
              <Inbox className="h-5 w-5" />
            </div>
            <p className="text-[10px] font-mono uppercase text-gray-400 tracking-wider">Business Inquiries</p>
            <h3 className="font-display font-black text-3xl text-white mt-2">
              {inquiries.length}
            </h3>
            <div className="flex items-center space-x-1.5 text-[11px] text-[#8FB3E0] mt-2 font-mono">
              <span>{inquiries.filter(i => i.inquiryType === 'brand_partnership').length} brand &bull; {inquiries.filter(i => i.inquiryType === 'speaking_engagement').length} speak</span>
            </div>
          </div>

          <div className="bg-[#16161F] border border-gray-800 p-5 rounded-2xl relative overflow-hidden">
            <div className="absolute top-4 right-4 text-amber-400 p-2 bg-amber-500/10 rounded-lg">
              <BarChart3 className="h-5 w-5" />
            </div>
            <p className="text-[10px] font-mono uppercase text-gray-400 tracking-wider">Newsletter Open Rate</p>
            <h3 className="font-display font-black text-3xl text-white mt-2">68.4%</h3>
            <div className="flex items-center space-x-1.5 text-[11px] text-emerald-400 mt-2 font-mono">
              <span>Industry benchmark scale ~25%</span>
            </div>
          </div>

          <div className="bg-[#16161F] border border-gray-800 p-5 rounded-2xl relative overflow-hidden">
            <p className="text-[10px] font-mono uppercase text-gray-400 tracking-wider">Residency Vitals</p>
            <h3 className="font-display font-extrabold text-sm text-emerald-300 mt-2">Stanford Med Hospital</h3>
            <p className="text-xs text-gray-400 mt-1">Status: Active Rotations</p>
            <p className="text-[10px] text-gray-500 font-mono mt-2">Updated 2h ago</p>
          </div>

        </div>

        {/* Dashboard Workspace Block */}
        <div className="bg-[#16161F] border border-gray-800 rounded-3xl overflow-hidden shadow-xl">
          
          {/* Workspace Search & Filter Tab bar */}
          <div className="border-b border-gray-850 p-5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-gray-900/40">
            <div className="flex space-x-2">
              <button
                onClick={() => {
                  setActiveTab('inquiries');
                  setSearchTerm('');
                  setSelectedInquiryId(null);
                }}
                className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold flex items-center space-x-2 transition-all cursor-pointer select-none ${
                  activeTab === 'inquiries'
                    ? 'bg-[#5865F2] text-white shadow-lg'
                    : 'bg-gray-900/60 border border-gray-800 text-gray-400 hover:text-white'
                }`}
              >
                <Inbox className="h-4 w-4" />
                <span>Business Inquiries Inbox ({inquiries.length})</span>
              </button>

              <button
                onClick={() => {
                  setActiveTab('subscribers');
                  setSearchTerm('');
                  setSelectedInquiryId(null);
                }}
                className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold flex items-center space-x-2 transition-all cursor-pointer select-none ${
                  activeTab === 'subscribers'
                    ? 'bg-[#5865F2] text-white shadow-lg'
                    : 'bg-gray-900/60 border border-gray-800 text-gray-400 hover:text-white'
                }`}
              >
                <FileSpreadsheet className="h-4 w-4" />
                <span>Newsletter Directory ({subscribers.length})</span>
              </button>
            </div>

            {/* Filter Input */}
            <div className="relative">
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder={`Search ${activeTab === 'inquiries' ? 'proposals' : 'emails'}...`}
                className="bg-gray-950 border border-gray-850 rounded-xl px-4 py-2 text-xs sm:text-sm text-white placeholder-gray-500 focus:outline-none focus:border-[#5865F2] transition-colors w-full sm:w-64"
              />
            </div>
          </div>

          {/* MAIN LISTS CONTENT */}
          <div className="p-6">
            {activeTab === 'subscribers' ? (
              /* TAB: Newsletter Subscribers */
              <div className="overflow-x-auto">
                {filteredSubs.length > 0 ? (
                  <table className="w-full text-sm text-left">
                    <thead>
                      <tr className="border-b border-gray-850 text-xs uppercase tracking-wider text-gray-450 font-mono">
                        <th className="py-3 px-4">Recipient Name</th>
                        <th className="py-3 px-4">Email Address</th>
                        <th className="py-3 px-4">Chosen Blueprint Guide</th>
                        <th className="py-3 px-4">Submitted At</th>
                        <th className="py-3 px-4 text-right">Delete</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-850">
                      {filteredSubs.map((sub, index) => (
                        <tr key={sub.id} className="hover:bg-gray-900/30 transition-colors">
                          <td className="py-3.5 px-4 font-semibold text-white">
                            {sub.name}
                            {index >= PRELOADED_SUBSCRIBERS.length && (
                              <span className="ml-1.5 inline-block px-1.5 py-0.5 bg-emerald-500/20 text-emerald-300 rounded text-[9px] font-mono tracking-widest font-bold">
                                NEW
                              </span>
                            )}
                          </td>
                          <td className="py-3.5 px-4 font-mono text-gray-300">{sub.email}</td>
                          <td className="py-3.5 px-4">
                            <span className="text-xs text-[#8FB3E0] font-medium bg-[#5865F2]/10 border border-[#5865F2]/15 rounded px-2.5 py-1">
                              {getMagnetTitle(sub.leadMagnetId)}
                            </span>
                          </td>
                          <td className="py-3.5 px-4 text-xs text-gray-400 font-mono">{sub.submittedAt}</td>
                          <td className="py-3.5 px-4 text-right">
                            <button
                              onClick={() => onDeleteSubscriber(sub.id)}
                              className="text-gray-500 hover:text-red-400 p-1 rounded-lg transition-colors cursor-pointer select-none"
                              title="Delete subscription row"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                ) : (
                  <div className="py-12 text-center text-gray-500 space-y-2">
                    <p className="text-sm">No subscriber search matches found.</p>
                    <p className="text-xs">Submit your email inside the Newsletter section below then return here!</p>
                  </div>
                )}
              </div>
            ) : (
              /* TAB: Collaboration Inquiries */
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                
                {/* Left Side: List of Inquiry Cards */}
                <div className="space-y-3.5 max-h-[500px] overflow-y-auto pr-2">
                  {filteredInqs.length > 0 ? (
                    filteredInqs.map((inq, index) => (
                      <div
                        key={inq.id}
                        onClick={() => setSelectedInquiryId(inq.id)}
                        className={`p-4 rounded-xl border text-left transition-all cursor-pointer ${
                          selectedInquiryId === inq.id
                            ? 'bg-[#5865F2]/10 border-[#5865F2] shadow-md'
                            : 'bg-[#121217]/60 border-gray-800 hover:border-gray-700'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className={`text-[9px] font-bold font-mono uppercase px-2 py-0.5 rounded ${
                            inq.inquiryType === 'brand_partnership'
                              ? 'bg-amber-500/10 text-amber-400'
                              : inq.inquiryType === 'speaking_engagement'
                              ? 'bg-purple-500/10 text-purple-400'
                              : 'bg-blue-500/10 text-blue-400'
                          }`}>
                            {inq.inquiryType.replace('_', ' ')}
                          </span>

                          <span className="text-[10px] font-mono text-gray-500">
                            {inq.submittedAt}
                          </span>
                        </div>

                        <h4 className="font-display font-bold text-sm text-white mt-2">
                          {inq.organization || inq.name}
                        </h4>
                        <p className="text-xs text-gray-300 font-sans line-clamp-1 mt-1">
                          "{inq.message}"
                        </p>

                        <div className="flex items-center justify-between mt-3 pt-2.5 border-t border-gray-850/60 text-[11px] text-gray-400">
                          <span>From: {inq.name}</span>
                          <span className="text-xs text-[#8FB3E0] group-hover:underline">Explore Message &rarr;</span>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="py-12 text-center text-gray-500">
                      <p className="text-sm">No inquiries available.</p>
                    </div>
                  )}
                </div>

                {/* Right Side: Detailed Message Vetting Viewport */}
                <div className="bg-[#0E0E12]/80 border border-gray-800/85 p-6 rounded-2xl min-h-[400px] text-left flex flex-col justify-between">
                  {selectedInquiryId ? (
                    (() => {
                      const activeInq = inquiries.find(i => i.id === selectedInquiryId);
                      if (!activeInq) return <p className="text-gray-500 text-sm">Select an email to vet details</p>;
                      
                      return (
                        <div className="space-y-6 flex-1 flex flex-col justify-between">
                          
                          {/* Inner Top Card details */}
                          <div className="space-y-4">
                            
                            <div className="flex items-center justify-between border-b border-gray-850 pb-3">
                              <div>
                                <h3 className="font-display font-black text-base text-white">
                                  {activeInq.organization || 'Inquiry Details'}
                                </h3>
                                <p className="text-xs text-gray-400">{activeInq.name} &bull; <span className="font-mono">{activeInq.email}</span></p>
                              </div>

                              <button
                                onClick={() => {
                                  onDeleteInquiry(activeInq.id);
                                  setSelectedInquiryId(null);
                                }}
                                className="p-1.5 text-gray-500 hover:text-red-400 rounded hover:bg-gray-900 transition-colors cursor-pointer"
                                title="Delete Proposal record"
                              >
                                <Trash2 className="h-4.5 w-4.5" />
                              </button>
                            </div>

                            {/* Inquiry Tag details bar */}
                            <div className="flex flex-wrap gap-2 text-[10px] font-mono">
                              <span className="px-2 py-0.5 bg-gray-900 rounded border border-gray-800 text-gray-400">
                                TYPE: {activeInq.inquiryType.toUpperCase()}
                              </span>
                              <span className="px-2 py-0.5 bg-gray-900 rounded border border-gray-800 text-gray-400">
                                DATE: {activeInq.submittedAt}
                              </span>
                            </div>

                            {/* Message box */}
                            <div className="space-y-2">
                              <span className="text-[10px] text-gray-500 font-mono uppercase block">PROPOSAL PITCH BLOCK</span>
                              <div className="bg-gray-950 p-4 rounded-xl border border-gray-900 text-sm text-gray-300 leading-relaxed max-h-[190px] overflow-y-auto font-sans">
                                "{activeInq.message}"
                              </div>
                            </div>

                          </div>

                          {/* Inner Bottom Reply interface */}
                          <div className="border-t border-gray-850 pt-4 space-y-3">
                            <span className="text-[10px] text-gray-500 font-mono uppercase block">DRAFT LIVE EMAIL REACTION</span>
                            
                            <div className="relative">
                              <input
                                type="text"
                                value={replyText}
                                onChange={(e) => setReplyText(e.target.value)}
                                placeholder={`Reply to ${activeInq.email}...`}
                                className="w-full bg-[#16161F] border border-gray-855 rounded-xl px-3.5 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-emerald-500"
                              />
                            </div>

                            <div className="flex items-center justify-between">
                              <span className="text-[9px] text-gray-500 italic">Prepares academic calendar options automatically.</span>
                              <button
                                onClick={() => handleSendReply(activeInq.id)}
                                className="px-3.5 py-1.5 bg-emerald-500 hover:bg-emerald-600 text-black text-xs font-bold rounded-lg flex items-center space-x-1.5 cursor-pointer"
                              >
                                {sentReply === activeInq.id ? (
                                  <>
                                    <CheckCheck className="h-3.5 w-3.5" />
                                    <span>Sent!</span>
                                  </>
                                ) : (
                                  <>
                                    <Send className="h-3 w-3" />
                                    <span>Send Response</span>
                                  </>
                                )}
                              </button>
                            </div>
                          </div>

                        </div>
                      );
                    })()
                  ) : (
                    <div className="flex flex-col items-center justify-center space-y-2 text-center h-full flex-1 text-gray-500 py-12">
                      <Inbox className="h-8 w-8 text-gray-600 stroke-1" />
                      <p className="text-sm">Select an inquiry to review proposals</p>
                      <p className="text-xs max-w-xs leading-relaxed text-gray-500">
                        Submit a Speaking Request or Brand Proposal on the Contact Form then review its message blocks here immediately.
                      </p>
                    </div>
                  )}
                </div>

              </div>
            )}
          </div>

        </div>

      </div>
    </div>
  );
}

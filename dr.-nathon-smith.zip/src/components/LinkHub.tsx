import React from 'react';
import { Share2, ExternalLink, Youtube, Instagram, FileText, Download, Play, MessageSquare, ShieldCheck } from 'lucide-react';
import { BIO_LINKS } from '../data';

export default function LinkHub() {
  
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'youtube':
        return <Youtube className="h-5 w-5 text-red-500" />;
      case 'instagram':
        return <Instagram className="h-5 w-5 text-pink-500" />;
      case 'file-text':
        return <FileText className="h-5 w-5 text-emerald-500" />;
      case 'download':
        return <Download className="h-5 w-5 text-[#5865F2]" />;
      default:
        return <Play className="h-5 w-5 text-[#8FB3E0]" />;
    }
  };

  return (
    <section id="link-hub" className="py-20 border-b border-white/5 relative">
      <div className="absolute top-1/3 right-10 w-[200px] h-[200px] bg-[#5865F2]/5 blur-[90px] rounded-full pointer-events-none"></div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        
        {/* Section Heading */}
        <div className="text-center mb-10">
          <span className="px-3.5 py-1.5 bg-white/5 border border-white/10 rounded-full text-[10px] font-bold uppercase tracking-widest text-[#8FB3E0]">
            Nathon's Link Directory
          </span>
          <h2 className="font-display font-black text-3xl text-white mt-4 tracking-tight">
            Start Here & Bio Resources
          </h2>
          <p className="text-gray-400 text-sm mt-2 max-w-lg mx-auto">
            Replacing standard basic bio links — explore Dr. Nathon's social classrooms, clinical publications, and collaborative documents.
          </p>
        </div>

        {/* Linktree Box layout */}
        <div className="bg-white/5 border border-white/10 rounded-3xl p-6 sm:p-8 space-y-4 shadow-2xl relative backdrop-blur-xl">
          
          <div className="flex items-center justify-between border-b border-white/5 pb-4 mb-2">
            <div className="flex items-center space-x-3 text-left">
              <div className="h-10 w-10 rounded-full overflow-hidden bg-gray-900 border border-[#5865F2]/30">
                <img
                  src="https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&w=120&q=80"
                  alt="Dr. Nathon avatar image link"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <h3 className="text-sm font-semibold text-white tracking-tight">@drnathonsmith</h3>
                <p className="text-[10px] text-gray-500 font-mono text-left">harvard &bull; stanford med</p>
              </div>
            </div>

            <span className="inline-flex items-center text-[10px] font-mono bg-[#5865F2]/10 text-[#8FB3E0] border border-white/10 px-2.5 py-0.5 rounded-full font-bold">
              <ShieldCheck className="h-3 w-3 mr-1" />
              Verified Doctor
            </span>
          </div>

          <div className="space-y-3.5">
            {BIO_LINKS.map((link) => (
              <a
                key={link.id}
                href={link.url}
                target={link.isExternal ? '_blank' : '_self'}
                rel="noopener noreferrer"
                className="group relative flex items-center justify-between p-4 bg-[#0E0E12]/40 hover:bg-[#5865F2]/15 border border-white/5 hover:border-[#5865F2]/50 rounded-2xl transition-all shadow-md"
              >
                <div className="flex items-center space-x-4 text-left">
                  <div className="p-2.5 bg-white/5 group-hover:bg-[#5865F2]/20 rounded-xl border border-white/10 group-hover:border-[#5865F2]/30 text-[#8FB3E0] transition-colors shrink-0">
                    {getIcon(link.iconName)}
                  </div>
                  
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="font-display font-bold text-sm sm:text-base text-gray-100 group-hover:text-white transition-colors">
                        {link.title}
                      </span>
                      {link.badge && (
                        <span className="px-2 py-0.5 bg-[#5865F2]/20 text-[#8FB3E0] text-[9px] font-bold font-mono rounded">
                          {link.badge}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-gray-400 mt-0.5 line-clamp-1 max-w-[280px] sm:max-w-[420px]">
                      {link.description}
                    </p>
                  </div>
                </div>

                <div className="text-gray-500 group-hover:text-[#8FB3E0] transition-transform group-hover:translate-x-1 shrink-0 ml-2">
                  <ExternalLink className="h-4 w-4" />
                </div>
              </a>
            ))}
          </div>

          {/* Bottom quick micro profile share */}
          <div className="pt-4 mt-6 border-t border-white/5 flex items-center justify-between text-[11px] text-gray-500 font-mono">
            <span>drnathonsmith.com Hub</span>
            <span className="flex items-center space-x-1 hover:text-white transition-colors cursor-pointer">
              <Share2 className="h-3 w-3" />
              <span>Share Card</span>
            </span>
          </div>

        </div>

      </div>
    </section>
  );
}

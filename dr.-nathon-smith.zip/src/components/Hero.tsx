import React, { useState } from 'react';
import { ShieldCheck, ArrowRight, Play, Youtube, Instagram, CheckCircle2, Award, Calendar, ChevronRight } from 'lucide-react';
import { motion } from 'motion/react';

interface HeroProps {
  onNewsletterSignup: (email: string, name: string, leadMagnetId: string) => void;
  onScrollToSection: (sectionId: string) => void;
}

export default function Hero({ onNewsletterSignup, onScrollToSection }: HeroProps) {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [signedUp, setSignedUp] = useState(false);

  const handleQuickSignup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    onNewsletterSignup(email, name || 'Reader', 'blueprint-longevity');
    setSignedUp(true);
    setEmail('');
    setName('');
  };

  return (
    <section className="relative overflow-hidden pt-8 pb-16 md:py-24">
      {/* Background Abstract Glows */}
      <div className="absolute top-1/4 left-1/3 w-[500px] h-[500px] bg-[#5865F2]/10 blur-[130px] rounded-full pointer-events-none z-0"></div>
      <div className="absolute top-1/2 right-10 w-[300px] h-[300px] bg-[#8FB3E0]/5 blur-[100px] rounded-full pointer-events-none z-0"></div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Column LEFT: Copy & Quick capture -- Takes 7 cols on large */}
          <div className="lg:col-span-7 flex flex-col space-y-6 text-left">
            
            {/* Harvard / Stanford Highlight badge */}
            <div className="flex gap-3 mb-2 flex-wrap">
              <span className="px-3.5 py-1.5 bg-white/5 border border-white/10 rounded-full text-[10px] font-bold uppercase tracking-widest text-[#8FB3E0] flex items-center gap-1.5 backdrop-blur-md">
                <Award className="h-3.5 w-3.5 text-[#5865F2]" />
                Harvard MD
              </span>
              <span className="px-3.5 py-1.5 bg-white/5 border border-white/10 rounded-full text-[10px] font-bold uppercase tracking-widest text-[#8FB3E0] flex items-center gap-1.5 backdrop-blur-md">
                <ShieldCheck className="h-3.5 w-3.5 text-[#5865F2]" />
                Stanford Resident
              </span>
            </div>

            {/* Headline and Tagline */}
            <div className="space-y-4">
              <h1 className="text-5xl sm:text-6xl lg:text-7xl font-extrabold leading-[0.95] tracking-tighter mb-4 text-white uppercase">
                MEDICINE <br/>EXPLAINED IN <br/>
                <span className="text-[#5865F2] tracking-tighter">
                  PLAIN ENGLISH.
                </span>
              </h1>
              <p className="text-lg text-gray-400 font-sans max-w-xl leading-relaxed">
                I translate high-yield clinical data, longevity research, and medical science into simple, actionable routines. No medical jargon — just evidence-based health optimization.
              </p>
            </div>

            {/* Audience indicators */}
            <div className="flex flex-wrap gap-x-6 gap-y-2 py-2 text-xs font-mono text-gray-400">
              <div className="flex items-center space-x-1.5">
                <CheckCircle2 className="h-4 w-4 text-[#5865F2] fill-[#5865F2]/10" />
                <span>1.5M+ Social Following</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <CheckCircle2 className="h-4 w-4 text-[#5865F2] fill-[#5865F2]/10" />
                <span>95% Engagement Rate</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <CheckCircle2 className="h-4 w-4 text-[#5865F2] fill-[#5865F2]/10" />
                <span>Evidence-Backed Insights</span>
              </div>
            </div>

            {/* Above-The-Fold Micro Email signup card */}
            <div className="bg-white/5 border border-white/10 rounded-2xl p-6 shadow-xl backdrop-blur-xl max-w-md">
              {!signedUp ? (
                <form onSubmit={handleQuickSignup} className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-gray-200 tracking-wide uppercase font-display">
                      Join 45,000+ for high-yield health tips
                    </span>
                    <span className="inline-block px-2 py-0.5 bg-[#5865F2]/25 text-[#8FB3E0] rounded font-mono text-[9px] font-bold">
                      FREE BLUEPRINT
                    </span>
                  </div>
                  <p className="text-xs text-gray-400">
                    Get my 25-page Longevity Blueprint immediately when you subscribe today.
                  </p>
                  
                  <div className="flex flex-col sm:flex-row gap-2">
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="Email address"
                      className="flex-1 bg-[#1A1A22] border border-white/10 rounded-lg px-4 py-2 text-sm text-white focus:outline-none focus:border-[#5865F2] transition-colors"
                    />
                    <button
                      type="submit"
                      className="bg-[#5865F2] hover:bg-[#4752C4] text-white text-xs font-bold px-6 py-2 rounded-lg transition-colors flex items-center justify-center space-x-1 cursor-pointer whitespace-nowrap active:scale-95"
                    >
                      <span>Join Now</span>
                      <ArrowRight className="h-3 w-3" />
                    </button>
                  </div>
                </form>
              ) : (
                <div className="py-2 text-center">
                  <div className="inline-flex items-center justify-center p-2 bg-[#5865F2]/10 rounded-full text-[#8FB3E0] mb-2">
                    <CheckCircle2 className="h-6 w-6" />
                  </div>
                  <h4 className="text-sm font-semibold text-white">You have successfully subscribed!</h4>
                  <p className="text-xs text-gray-400 mt-1">
                    Check your inbox. We sent your <strong>Longevity Protocol</strong> file. You can also review it down below.
                  </p>
                  <button 
                    onClick={() => onScrollToSection('newsletter')}
                    className="mt-3 text-xs text-[#8FB3E0] underline font-medium hover:text-white"
                  >
                    Browse other free guides &rarr;
                  </button>
                </div>
              )}
            </div>

            {/* Quick Action buttons */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 pt-2">
              <button
                onClick={() => onScrollToSection('content-insights')}
                className="bg-[#5865F2] hover:bg-[#4d5add] text-white font-medium text-sm px-6 py-3 rounded-lg transition-all flex items-center justify-center space-x-2 shadow-lg hover:shadow-[#5865F2]/10 active:scale-95 cursor-pointer"
              >
                <Play className="h-4 w-4 fill-white" />
                <span>Watch the Content</span>
              </button>
              
              <button
                onClick={() => onScrollToSection('newsletter')}
                className="bg-white/5 border border-white/10 backdrop-blur-xl hover:bg-white/10 text-gray-300 font-medium text-sm px-6 py-3 rounded-lg transition-all flex items-center justify-center space-x-2 cursor-pointer"
              >
                <span>Browse Resource Hub</span>
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>

          </div>

          {/* Column RIGHT: Beautiful 3D Styled Frame representing Dr. Nathon Smith -- Takes 5 cols */}
          <div className="lg:col-span-5 relative flex items-center justify-center z-10">
            
            {/* Visual background decorations for the portrait */}
            <div className="absolute inset-0 bg-gradient-to-tr from-[#5865F2]/20 to-[#8FB3E0]/10 rounded-[32px] rotate-3 blur-sm pointer-events-none scale-102"></div>
            
            <div className="relative bg-white/5 border border-white/10 p-3 rounded-[32px] w-full max-w-[360px] sm:max-w-[380px] shadow-2xl overflow-hidden group backdrop-blur-xl">
              
              {/* Actual Image container with high quality doctor from Unsplash */}
              <div className="relative aspect-[4/5] rounded-[24px] overflow-hidden bg-gray-950">
                <img
                  src="https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&w=600&q=80"
                  alt="Dr. Nathon Smith Portrait"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-top filter contrast-105 brightness-100 transition-all duration-700 group-hover:scale-105"
                />
                
                {/* Floating tags */}
                <div className="absolute bottom-4 left-4 right-4 bg-[#0E0E12]/80 border border-white/10 p-3 rounded-xl backdrop-blur-md">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-display font-semibold text-sm text-white">Dr. Nathon Smith, MD</h3>
                      <p className="text-[11px] text-gray-400">Harvard Medical School &bull; Stanford Residency</p>
                    </div>
                    <div className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" title="Vetting verified information"></div>
                  </div>
                </div>

                {/* Top badge */}
                <div className="absolute top-4 right-4 bg-[#5865F2]/90 border border-white/10 px-3 py-1 rounded-full text-[10px] font-mono text-white tracking-widest uppercase font-bold backdrop-blur-sm">
                  Clinical Educator
                </div>
              </div>

              {/* Decorative side borders */}
              <div className="absolute top-1/2 -left-3 -translate-y-1/2 p-2.5 bg-[#5865F2]/10 rounded-r-lg border-y border-r border-[#5865F2]/20 text-[#5865F2] flex items-center justify-center">
                <Instagram className="h-4 w-4" />
              </div>
              <div className="absolute top-1/2 -right-3 -translate-y-1/2 p-2.5 bg-[#5865F2]/10 rounded-l-lg border-y border-l border-[#5865F2]/20 text-[#5865F2] flex items-center justify-center">
                <Youtube className="h-4 w-4" />
              </div>

            </div>

          </div>

        </div>
      </div>
    </section>
  );
}

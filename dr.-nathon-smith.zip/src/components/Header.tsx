import React from 'react';
import { Stethoscope, ShieldAlert, Award, Database, TrendingUp, Menu, X, Flame } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface HeaderProps {
  showDashboard: boolean;
  onToggleDashboard: () => void;
  subscriberCount: number;
  inquiryCount: number;
}

export default function Header({
  showDashboard,
  onToggleDashboard,
  subscriberCount,
  inquiryCount
}: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  return (
    <header className="sticky top-0 z-40 bg-[#0E0E12]/80 backdrop-blur-md border-b border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo Brand */}
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-[#5865F2]/10 rounded-lg border border-[#5865F2]/20 text-[#5865F2] flex items-center justify-center">
              <Stethoscope className="h-5 w-5 animate-pulse" />
            </div>
            <div>
              <span className="font-display font-bold text-lg text-white tracking-tight">
                Dr. Nathon Smith
              </span>
              <span className="hidden sm:inline-block ml-2 px-2.5 py-0.5 bg-white/5 border border-white/10 rounded text-[9px] text-[#8FB3E0] font-mono tracking-widest uppercase">
                Ed-Med Hub
              </span>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8 items-center">
            <a href="#content-insights" className="text-sm font-medium text-gray-300 hover:text-[#5865F2] transition-colors">
              Content Insights
            </a>
            <a href="#about-story" className="text-sm font-medium text-gray-300 hover:text-[#5865F2] transition-colors">
              About
            </a>
            <a href="#link-hub" className="text-sm font-medium text-gray-300 hover:text-[#5865F2] transition-colors">
              Resources
            </a>
            <a href="#collaborate" className="text-sm font-medium text-gray-300 hover:text-[#5865F2] transition-colors">
              Collaborate
            </a>
            <a href="#newsletter" className="px-3 py-1.5 bg-white/5 border border-white/10 text-[#8FB3E0] hover:bg-white/10 rounded-lg text-xs font-semibold tracking-wide transition-all flex items-center gap-1.5">
              <Flame className="h-3.5 w-3.5 text-amber-500 fill-amber-500/25" />
              Free Guides
            </a>
          </nav>

          {/* Action Buttons */}
          <div className="hidden md:flex items-center space-x-3">
            <button
              onClick={onToggleDashboard}
              id="header_dashboard_toggle"
              className={`px-4 py-1.5 rounded-lg text-xs font-mono flex items-center space-x-2 transition-all cursor-pointer ${
                showDashboard
                  ? 'bg-emerald-500/25 text-emerald-300 border border-emerald-500'
                  : 'bg-[#5865F2]/10 text-[#8FB3E0] hover:bg-[#5865F2]/20 border border-[#5865F2]/30'
              }`}
            >
              <Database className="h-3.5 w-3.5" />
              <span>{showDashboard ? 'Back to Brand' : 'Creator Portal'}</span>
              {!showDashboard && (
                <span className="bg-red-500 text-white font-sans font-bold px-1.5 py-0.5 rounded-full text-[9px] animate-bounce">
                  Live
                </span>
              )}
            </button>
          </div>

          {/* Mobile Menu Icon */}
          <div className="flex md:hidden items-center space-x-2">
            <button
              onClick={onToggleDashboard}
              className={`p-1 w-9 h-9 rounded-lg text-xs font-mono flex items-center justify-center transition-all cursor-pointer ${
                showDashboard
                  ? 'bg-emerald-500/25 text-emerald-300 border border-emerald-500'
                  : 'bg-[#5865F2]/10 text-brand-secondary border border-[#5865F2]/20'
              }`}
              title="Creator Portal"
            >
              <Database className="h-4 w-4" />
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-1.5 text-gray-400 hover:text-white bg-gray-800/50 rounded-lg border border-gray-700/40 select-none"
            >
              {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-[#0E0E12]/95 backdrop-blur-md border-b border-white/10"
          >
            <div className="px-4 pt-2 pb-6 space-y-3">
              <a
                href="#content-insights"
                onClick={() => setMobileMenuOpen(false)}
                className="block px-3 py-2.5 rounded-md text-base font-medium text-gray-300 hover:bg-white/5 hover:text-white"
              >
                Content Insights
              </a>
              <a
                href="#about-story"
                onClick={() => setMobileMenuOpen(false)}
                className="block px-3 py-2.5 rounded-md text-base font-medium text-gray-300 hover:bg-white/5 hover:text-white"
              >
                About
              </a>
              <a
                href="#link-hub"
                onClick={() => setMobileMenuOpen(false)}
                className="block px-3 py-2.5 rounded-md text-base font-medium text-gray-300 hover:bg-white/5 hover:text-white"
              >
                Resources & Start
              </a>
              <a
                href="#collaborate"
                onClick={() => setMobileMenuOpen(false)}
                className="block px-3 py-2.5 rounded-md text-base font-medium text-gray-300 hover:bg-white/5 hover:text-white"
              >
                Collaborate & Inquiries
              </a>
              <a
                href="#newsletter"
                onClick={() => setMobileMenuOpen(false)}
                className="block px-3 py-2.5 rounded-md text-base font-medium text-[#8FB3E0] hover:bg-white/5"
              >
                ⚡ Download Clinical Blueprints
              </a>

              <div className="pt-2 border-t border-white/10 flex flex-col items-center">
                <button
                  onClick={() => {
                    onToggleDashboard();
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full py-2.5 rounded-lg text-sm font-mono flex items-center justify-center space-x-2 transition-all ${
                    showDashboard
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/50'
                      : 'bg-[#5865F2] hover:bg-[#4752C4] text-white'
                  }`}
                >
                  <Database className="h-4 w-4" />
                  <span>{showDashboard ? "Exit Back-Office Panel" : "Open Creator Back-Office"}</span>
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}

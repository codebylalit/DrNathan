import React from 'react';
import { Award, BookOpen, Stethoscope, Heart, Flame, ShieldAlert, Sparkles, GraduationCap } from 'lucide-react';

export default function About() {
  return (
    <section id="about-story" className="bg-[#121217] py-20 border-b border-gray-900 overflow-hidden relative">
      <div className="absolute top-1/2 left-0 -translate-y-1/2 w-[350px] h-[350px] bg-[#8FB3E0]/5 blur-[120px] rounded-full pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Training Timeline & Key Credentials */}
          <div className="lg:col-span-5 space-y-6 order-2 lg:order-1">
            <div className="bg-[#16161F] border border-gray-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl relative">
              <div className="absolute top-0 right-0 transform translate-x-1/4 -translate-y-1/4 w-16 h-16 bg-[#5865F2]/10 blur-xl rounded-full"></div>
              
              <h3 className="font-display font-black text-xl text-white tracking-tight border-b border-gray-800 pb-3">
                Academic Pedigree
              </h3>

              {/* Timeline list */}
              <div className="space-y-6 relative border-l-2 border-gray-800 pl-4 ml-2">
                <div className="relative">
                  {/* Timeline bullet */}
                  <span className="absolute -left-[25px] top-1.5 h-3 w-3 rounded-full bg-[#5865F2] ring-4 ring-[#5865F2]/10"></span>
                  <div className="text-left">
                    <span className="inline-block px-2 py-0.5 bg-[#A51C30]/10 text-[#A51C30] border border-[#A51C30]/15 rounded text-[10px] font-mono font-bold uppercase">
                      Graduated MD
                    </span>
                    <h4 className="text-sm font-semibold text-white mt-1">Harvard Medical School</h4>
                    <p className="text-xs text-gray-400">Class of 2023. Honors Thesis researching metabolic disorders and cardiorespiratory fitness metrics.</p>
                  </div>
                </div>

                <div className="relative">
                  {/* Timeline bullet */}
                  <span className="absolute -left-[25px] top-1.5 h-3 w-3 rounded-full bg-[#8FB3E0] ring-4 ring-[#8FB3E0]/10"></span>
                  <div className="text-left">
                    <span className="inline-block px-2 py-0.5 bg-[#8C1515]/10 text-[#8C1515] border border-[#8C1515]/15 rounded text-[10px] font-mono font-bold uppercase">
                      Current Residency
                    </span>
                    <h4 className="text-sm font-semibold text-white mt-1">Stanford Health Care</h4>
                    <p className="text-xs text-gray-400">Internal Medicine Resident. Focusing on preventative clinical workflows, hypertension and longevity indices.</p>
                  </div>
                </div>

                <div className="relative">
                  {/* Timeline bullet */}
                  <span className="absolute -left-[25px] top-1.5 h-3 w-3 rounded-full bg-emerald-500 ring-4 ring-emerald-500/10"></span>
                  <div className="text-left">
                    <span className="inline-block px-2 py-0.5 bg-emerald-500/10 text-emerald-300 border border-emerald-500/15 rounded text-[10px] font-mono font-bold uppercase">
                      Present Channel
                    </span>
                    <h4 className="text-sm font-semibold text-white mt-1">Short-form Health Educator</h4>
                    <p className="text-xs text-gray-400">Publishing evidence-based reels and briefs reaching over 50 million viewers annually worldwide.</p>
                  </div>
                </div>
              </div>

              {/* Integrity Shield widget */}
              <div className="p-3.5 bg-gray-900/60 rounded-2xl border border-gray-805 flex items-start space-x-3 text-left">
                <GraduationCap className="h-5 w-5 text-[#8FB3E0] mt-0.5 shrink-0" />
                <p className="text-[11px] text-gray-400 leading-normal">
                  <strong>Strict Clinical Standards:</strong> Every video and content draft undergoes a rigorous literature review. Dr. Smith is dedicated to public health literacy and does not accept sponsorships from unvetted supplement products.
                </p>
              </div>

            </div>
          </div>

          {/* Right Column: Narrative Biography */}
          <div className="lg:col-span-7 space-y-6 text-left order-1 lg:order-2">
            <span className="text-xs font-mono tracking-widest text-[#8FB3E0] uppercase font-bold px-3 py-1 bg-[#8FB3E0]/10 rounded-full">
              The Mission & Story
            </span>
            
            <h2 className="font-display font-black text-3xl sm:text-4xl text-white tracking-tight leading-tight">
              Why I Trade the Clinical Clinic for the Creator Camera
            </h2>

            <div className="space-y-4 text-sm text-gray-300 leading-relaxed">
              <p>
                During my clinical training at Harvard, I sat face-to-face with patients daily who spent thousands on miracle remedies and questionable social media supplements. Meanwhile, they missed basic, life-changing tenets: <strong>meal timing schedules, blood pressure mechanics, sleep architecture, and critical metabolic screening markers.</strong>
              </p>
              
              <div className="p-4 bg-[#5865F2]/5 border-l-4 border-[#5865F2] rounded-r-xl my-4">
                <p className="text-[#8FB3E0] font-medium italic">
                  "Health information is currently locked behind scientific paywalls or distorted by fitness influencers. Evidence-based medicine should not be a privilege. It must be accessible."
                </p>
              </div>

              <p>
                I founded my digital channels to act as an accessible antidote to wellness misinformation. Combining academic rigor from Harvard Medical School and day-to-day diagnostics from Stanford Health Care, my goal is to explain complex physiological pathways in simple, high-yield routines.
              </p>

              <p>
                Whether you prefer to inspect continuous glucose monitor studies or simply wish to lower your blood pressure, these materials are designed to empower you with real clinical metrics to make optimized life modifications.
              </p>
            </div>

            {/* Quick credentials blocks */}
            <div className="grid grid-cols-3 gap-2 pt-4">
              <div className="bg-gray-900/40 p-3 rounded-xl border border-gray-850 text-center">
                <BookOpen className="mx-auto h-4 w-4 text-[#5865F2] mb-1" />
                <span className="text-[11px] font-semibold text-white block">Published</span>
                <span className="text-[9px] text-gray-500">12+ Peer Papers</span>
              </div>
              <div className="bg-gray-900/40 p-3 rounded-xl border border-gray-850 text-center">
                <Stethoscope className="mx-auto h-4 w-4 text-[#5865F2] mb-1" />
                <span className="text-[11px] font-semibold text-white block">Residency</span>
                <span className="text-[9px] text-gray-500">Internal Med</span>
              </div>
              <div className="bg-gray-900/40 p-3 rounded-xl border border-gray-850 text-center">
                <Heart className="mx-auto h-4 w-4 text-[#5865F2] mb-1" />
                <span className="text-[11px] font-semibold text-white block">Community</span>
                <span className="text-[9px] text-gray-500">950K+ IG Vetted</span>
              </div>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
}

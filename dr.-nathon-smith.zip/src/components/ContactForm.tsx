import React, { useState } from 'react';
import { Mail, CheckCircle2, ChevronDown, Send, Briefcase, FileText, Globe, Key } from 'lucide-react';
import { CollaborationInquiry } from '../types';

interface ContactFormProps {
  onInquirySubmit: (inquiry: Omit<CollaborationInquiry, 'id' | 'submittedAt'>) => void;
}

export default function ContactForm({ onInquirySubmit }: ContactFormProps) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [organization, setOrganization] = useState('');
  const [inquiryType, setInquiryType] = useState<CollaborationInquiry['inquiryType']>('brand_partnership');
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !message) return;

    setSubmitting(true);
    
    // Simulate short network delay
    setTimeout(() => {
      onInquirySubmit({
        name,
        email,
        organization,
        inquiryType,
        message
      });
      setSubmitting(false);
      setSubmitted(true);
      
      // Clear
      setName('');
      setEmail('');
      setOrganization('');
      setMessage('');
    }, 850);
  };

  return (
    <section id="collaborate" className="bg-[#0E0E12] py-20 border-b border-gray-900 relative">
      <div className="absolute bottom-10 left-10 w-[250px].5 h-[250px] bg-[#5865F2]/5 blur-[100px] rounded-full pointer-events-none"></div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Column LEFT: Press Kit & Technical Details (5 cols) */}
          <div className="lg:col-span-5 space-y-6 text-left">
            <div>
              <span className="text-xs font-mono tracking-widest text-[#8FB3E0] uppercase font-bold px-3 py-1 bg-[#8FB3E0]/10 rounded-full">
                Speaking & Partnerships
              </span>
              <h2 className="font-display font-black text-3xl text-white mt-4 tracking-tight leading-tight">
                Let's Collaborate on Evidence-Backed Ideas
              </h2>
              <p className="text-gray-400 text-sm mt-3 leading-relaxed">
                Empower your audience with authentic, top-tier clinical insight. Dr. Smith partners with health technology founders, scientific wellness brands, and academic institutions worldwide.
              </p>
            </div>

            {/* Quick Metrics & Vetting pillars */}
            <div className="space-y-4 pt-2">
              <div className="flex items-start space-x-3">
                <div className="p-2 bg-[#5865F2]/15 rounded-lg text-[#8FB3E0] shrink-0">
                  <Briefcase className="h-4.5 w-4.5" />
                </div>
                <div className="text-left">
                  <h4 className="text-sm font-semibold text-white">Brand Collabs</h4>
                  <p className="text-xs text-gray-400">Strictly vetting products for chemical and organic safety. No unproven multi-level supplements.</p>
                </div>
              </div>

              <div className="flex items-start space-x-3">
                <div className="p-2 bg-[#5865F2]/15 rounded-lg text-[#8FB3E0] shrink-0">
                  <Globe className="h-4.5 w-4.5" />
                </div>
                <div className="text-left">
                  <h4 className="text-sm font-semibold text-white">Keynotes & Panels</h4>
                  <p className="text-xs text-gray-400">Custom topics on digital public health, longevity biology, pre-diabetes mitigation, and sleep science.</p>
                </div>
              </div>

              <div className="flex items-start space-x-3">
                <div className="p-2 bg-[#5865F2]/15 rounded-lg text-[#8FB3E0] shrink-0">
                  <FileText className="h-4.5 w-4.5" />
                </div>
                <div className="text-left">
                  <h4 className="text-sm font-semibold text-white">Expert Writing</h4>
                  <p className="text-xs text-gray-400">Medical board reviewing, script validation, and product developmental feedback.</p>
                </div>
              </div>
            </div>

            {/* Direct Email fallback */}
            <div className="p-4 bg-[#16161F] border border-gray-800 rounded-2xl text-xs space-y-1">
              <span className="text-[#8FB3E0] font-bold block uppercase tracking-wider text-[10px]">Direct Clinical Office Email:</span>
              <p className="text-gray-300">partnership@drnathonsmith.com</p>
              <p className="text-[10px] text-gray-500 font-mono mt-0.5">Please allow 2 business days for residency schedule review.</p>
            </div>

          </div>

          {/* Column RIGHT: Beautiful form (7 cols) */}
          <div className="lg:col-span-7">
            <div className="bg-[#16161F] border border-gray-800 rounded-3xl p-6 sm:p-8 shadow-2xl relative">
              
              {!submitted ? (
                <form onSubmit={handleSubmit} className="space-y-4 text-left">
                  <p className="text-xs text-gray-400 border-b border-gray-800 pb-3 font-mono">
                    PROPOSE INQUIRY FORM • VETTED CHANNELS ONLY
                  </p>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-[10px] font-mono text-gray-400 uppercase tracking-widest block font-medium">Your Name</label>
                      <input
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="Nathon Smith"
                        className="w-full bg-[#0E0E12] border border-gray-800 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-[#5865F2] transition-colors"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-mono text-gray-400 uppercase tracking-widest block font-bold">Email Address</label>
                      <input
                        type="email"
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="partner@company.com"
                        className="w-full bg-[#0E0E12] border border-gray-800 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-[#5865F2] transition-colors"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-[10px] font-mono text-gray-400 uppercase tracking-widest block font-medium">Organization / Brand</label>
                      <input
                        type="text"
                        value={organization}
                        onChange={(e) => setOrganization(e.target.value)}
                        placeholder="e.g. Stanford Health"
                        className="w-full bg-[#0E0E12] border border-gray-800 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-[#5865F2] transition-colors"
                      />
                    </div>

                    <div className="space-y-1 relative">
                      <label className="text-[10px] font-mono text-gray-400 uppercase tracking-widest block font-medium">Inquiry Category</label>
                      <div className="relative">
                        <select
                          value={inquiryType}
                          onChange={(e) => setInquiryType(e.target.value as CollaborationInquiry['inquiryType'])}
                          className="w-full bg-[#0E0E12] border border-gray-800 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-[#5865F2] appearance-none cursor-pointer"
                        >
                          <option value="brand_partnership">Brand Sponsorship</option>
                          <option value="speaking_engagement">Speaking / Panel Invitation</option>
                          <option value="media_press">Media Interview / Quote</option>
                          <option value="other">Other Clinical Inquiries</option>
                        </select>
                        <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400 pointer-events-none" />
                      </div>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-mono text-gray-400 uppercase tracking-widest block font-medium">Proposal details & Message</label>
                    <textarea
                      required
                      rows={4}
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder="Outline your event, timeline, audience scale, or compensation parameters..."
                      className="w-full bg-[#0E0E12] border border-gray-800 rounded-xl p-3.5 text-sm text-white focus:outline-none focus:border-[#5865F2] transition-colors resize-none"
                    ></textarea>
                  </div>

                  <button
                    type="submit"
                    disabled={submitting}
                    className="w-full py-3 bg-[#5865F2] hover:bg-[#4752C4] text-white font-bold text-sm tracking-wide rounded-xl flex items-center justify-center space-x-2 transition-all disabled:opacity-50 cursor-pointer shadow-lg hover:shadow-[#5865F2]/20 active:scale-98"
                  >
                    {submitting ? (
                      <span className="animate-spin text-white">⌛ Vetting...</span>
                    ) : (
                      <>
                        <Send className="h-4 w-4" />
                        <span>Submit Vetted Business Inquiry</span>
                      </>
                    )}
                  </button>
                </form>
              ) : (
                <div className="text-center py-6 space-y-4">
                  <div className="inline-flex items-center justify-center p-3 bg-emerald-500/10 rounded-full text-emerald-400 border border-emerald-500/20 mb-2">
                    <CheckCircle2 className="h-8 w-8" />
                  </div>
                  
                  <div className="space-y-2 text-center">
                    <h3 className="font-display font-black text-xl text-white">
                      Inquiry Logged Securely!
                    </h3>
                    <p className="text-xs text-gray-401 max-w-sm mx-auto leading-relaxed">
                      Thank you for submitting, your proposal is saved. It has been routed immediately to Dr. Nathon's Creator Dashboard. Click `Creator Portal` on top right to view this and other inbox items!
                    </p>
                  </div>

                  <button
                    onClick={() => setSubmitted(false)}
                    className="mt-3 px-4 py-2 bg-[#5865F2]/10 hover:bg-[#5865F2]/20 border border-[#5865F2]/20 text-[#8FB3E0] text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                  >
                    Submit Another Inquiry
                  </button>
                </div>
              )}

            </div>
          </div>

        </div>
      </div>
    </section>
  );
}

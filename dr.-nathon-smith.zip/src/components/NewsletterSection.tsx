import React, { useState } from 'react';
import { Mail, CheckCircle2, Download, BookOpen, AlertCircle, FileText, Smartphone, ArrowRight, BookOpenCheck, BookmarkCheck } from 'lucide-react';
import { LEAD_MAGNETS } from '../data';
import { LeadMagnet } from '../types';
import { motion, AnimatePresence } from 'motion/react';

interface NewsletterSectionProps {
  onNewsletterSignup: (email: string, name: string, leadMagnetId: string) => void;
}

export default function NewsletterSection({ onNewsletterSignup }: NewsletterSectionProps) {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [selectedMagnetId, setSelectedMagnetId] = useState(LEAD_MAGNETS[0].id);
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [activeTab, setActiveTab] = useState(0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !name) return;
    onNewsletterSignup(email, name, selectedMagnetId);
    setIsSubscribed(true);
  };

  const currentMagnet = LEAD_MAGNETS.find((m) => m.id === selectedMagnetId) || LEAD_MAGNETS[0];

  return (
    <section id="newsletter" className="bg-[#121217] py-20 border-b border-gray-900 overflow-hidden relative">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#5865F2]/5 blur-[140px] rounded-full pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Column LEFT: Detailed Magnet Browser & Form */}
          <div className="lg:col-span-6 space-y-6 text-left">
            
            <div className="space-y-4">
              <span className="text-xs font-mono tracking-widest text-[#5865F2] uppercase font-bold px-3 py-1 bg-[#5865F2]/10 rounded-full">
                High-Yield Health Newsletter
              </span>
              
              <h2 className="font-display font-black text-3xl sm:text-4xl text-white tracking-tight leading-tight">
                Unlock Dr. Nathon's Medical Blueprints
              </h2>
              
              <p className="text-gray-400 text-sm sm:text-base leading-relaxed">
                Join our premium newsletter of 80,000+ clinicians and health optimizers. Receive science-backed clinical routines, health calculators, and long-term diagnostic protocols straight to your inbox weekly.
              </p>
            </div>

            {/* List Magnets Select Tabs */}
            <div className="space-y-3">
              <span className="text-xs font-mono uppercase text-gray-400 tracking-wider">
                Select Your Free Clinical Blueprint Resource:
              </span>
              
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {LEAD_MAGNETS.map((magnet) => (
                  <button
                    key={magnet.id}
                    onClick={() => {
                      setSelectedMagnetId(magnet.id);
                      setIsSubscribed(false); // Reset to allow viewing if category changes
                    }}
                    className={`p-3.5 rounded-xl border text-left flex flex-col justify-between h-28 cursor-pointer select-none transition-all ${
                      selectedMagnetId === magnet.id
                        ? 'bg-[#5865F2]/10 border-[#5865F2] text-white shadow-xl'
                        : 'bg-gray-900/60 border-gray-800 text-gray-400 hover:border-gray-700 hover:text-white'
                    }`}
                  >
                    <div>
                      <span className={`text-[9px] font-mono font-bold tracking-wide uppercase px-2 py-0.5 rounded ${
                        selectedMagnetId === magnet.id ? 'bg-[#5865F2] text-white' : 'bg-gray-800 text-gray-400'
                      }`}>
                        {magnet.badge}
                      </span>
                      <h4 className="font-display font-bold text-xs mt-2 line-clamp-2">
                        {magnet.title}
                      </h4>
                    </div>
                    
                    <span className="text-[10px] text-gray-500 font-mono">
                      {magnet.chapters.length} Chapters &bull; PDF
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Newsletter form with direct lead capture */}
            <div className="bg-[#16161F] border border-gray-800 p-6 sm:p-8 rounded-2xl shadow-xl">
              
              {!isSubscribed ? (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1 text-left">
                      <label className="text-xs font-mono text-gray-400 uppercase tracking-widest block">Your First Name</label>
                      <input
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="Nathon"
                        className="w-full bg-gray-900 border border-gray-800 rounded-lg px-3 py-2 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-[#5865F2] transition-colors"
                      />
                    </div>
                    
                    <div className="space-y-1 text-left">
                      <label className="text-xs font-mono text-gray-400 uppercase tracking-widest block font-bold">Email Address</label>
                      <input
                        type="email"
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="nathon.smith@stanford.edu"
                        className="w-full bg-gray-900 border border-gray-800 rounded-lg px-3 py-2 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-[#5865F2] transition-colors"
                      />
                    </div>
                  </div>

                  <div className="flex items-center space-x-2 text-xs text-gray-400">
                    <input type="checkbox" required defaultChecked className="rounded border-gray-800 text-[#5865F2] focus:ring-0 mr-1" id="agree_terms" />
                    <label htmlFor="agree_terms" className="cursor-pointer select-none">
                      I agree to receive weekly clinical updates. Unsubscribe anytime.
                    </label>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 bg-[#5865F2] hover:bg-[#4752C4] text-white font-bold text-sm tracking-wide rounded-xl flex items-center justify-center space-x-2 transition-all cursor-pointer shadow-lg hover:shadow-[#5865F2]/20 active:scale-98"
                  >
                    <Mail className="h-4.5 w-4.5" />
                    <span>Get Free Blueprint: {currentMagnet.title}</span>
                  </button>
                </form>
              ) : (
                <div className="text-center space-y-4">
                  <div className="inline-flex items-center justify-center p-3 bg-emerald-500/10 rounded-full text-emerald-400 border border-emerald-500/20 mb-1">
                    <CheckCircle2 className="h-8 w-8" />
                  </div>
                  
                  <div className="space-y-2">
                    <h3 className="font-display font-black text-lg text-white">
                      Welcome Onboard, {name}!
                    </h3>
                    <p className="text-xs text-gray-400 max-w-sm mx-auto">
                      Your subscription is active. We sent the digital file to <strong>{email}</strong>. For instant access, you can read the complete outline right here on the right!
                    </p>
                  </div>

                  <div className="pt-3 flex flex-wrap gap-2 justify-center">
                    <button
                      onClick={() => setIsSubscribed(false)}
                      className="px-4 py-2 bg-gray-900 border border-gray-800 hover:border-gray-700 text-xs text-gray-400 hover:text-white rounded-lg cursor-pointer"
                    >
                      Subscribe Another Email
                    </button>
                    <a
                      href={`/assets/${currentMagnet.downloadName}`}
                      download
                      onClick={(e) => {
                        e.preventDefault();
                        alert(`Downloaded file: ${currentMagnet.downloadName} successfully in sandboxed storage.`);
                      }}
                      className="px-4 py-2 bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/20 text-emerald-300 text-xs font-semibold rounded-lg flex items-center space-x-1"
                    >
                      <Download className="h-3.5 w-3.5" />
                      <span>Download PDF Blueprint</span>
                    </a>
                  </div>
                </div>
              )}

            </div>

          </div>

          {/* Column RIGHT: Dynamic Sandbox Blueprint Reader */}
          <div className="lg:col-span-6 relative">
            <div className="absolute -top-10 -right-10 w-24 h-24 bg-[#8FB3E0]/10 blur-xl rounded-full"></div>
            
            {/* Outline box representing the booklet */}
            <div className="bg-[#16161F] border border-gray-800 rounded-3xl p-6 sm:p-8 shadow-2xl relative">
              
              <div className="flex items-center justify-between border-b border-gray-850 pb-4 mb-4">
                <div className="flex items-center space-x-2 text-[#8FB3E0]">
                  <BookOpenCheck className="h-5 w-5" />
                  <span className="font-mono text-[11px] uppercase tracking-wider font-bold">
                    Interactive PDF Previewer
                  </span>
                </div>
                
                <span className="px-2 py-0.5 bg-gray-900 border border-gray-800 rounded-full font-mono text-[10px] text-gray-500">
                  Version 4.1
                </span>
              </div>

              {/* Cover layout */}
              <div className="bg-gray-950/80 border border-gray-900 rounded-2xl p-6 text-left space-y-4">
                
                {/* Book header */}
                <div className="space-y-1">
                  <span className="text-[9px] font-mono bg-[#5865F2]/20 text-[#8FB3E0] px-2 py-0.5 rounded font-black tracking-wide">
                    {currentMagnet.badge} Blueprints
                  </span>
                  
                  <h3 className="font-display font-black text-xl text-white tracking-tight pt-1">
                    {currentMagnet.title}
                  </h3>
                  
                  <p className="text-[11px] text-gray-500 font-sans italic">
                    Authored by Dr. Nathon Smith, MD (Harvard Scholar, Stanford Internist)
                  </p>
                </div>

                {/* Highlight box */}
                <div className="p-3 bg-gray-900 border border-gray-805 rounded-xl text-xs text-gray-300 space-y-2">
                  <p className="font-semibold text-gray-200">Abstract Description:</p>
                  <p className="text-gray-400 text-[11px] leading-relaxed">
                    {currentMagnet.description}
                  </p>
                </div>

                {/* Simulated table of contents */}
                <div className="space-y-2">
                  <span className="text-[10px] font-mono uppercase text-gray-500 block">
                    Curriculum Index ({currentMagnet.chapters.length} Key chapters)
                  </span>
                  
                  <div className="space-y-1.5">
                    {currentMagnet.chapters.map((chapterName, idx) => (
                      <div
                        key={idx}
                        onClick={() => setActiveTab(idx)}
                        className={`p-2.5 rounded-lg border text-xs text-left cursor-pointer transition-colors flex items-center space-x-2.5 ${
                          activeTab === idx
                            ? 'bg-[#5865F2]/10 border-[#5865F2] text-white'
                            : 'bg-gray-900/40 border-gray-900 text-gray-400 hover:bg-gray-900'
                        }`}
                      >
                        <span className="font-mono text-[10px] text-[#8FB3E0] bg-[#8FB3E0]/10 h-5 w-5 rounded-full flex items-center justify-center">
                          0{idx+1}
                        </span>
                        <span className="line-clamp-1 flex-1">{chapterName}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Deep reader screen display based on active chapter tab */}
                <div className="p-3.5 bg-[#121217] border border-gray-800 rounded-xl relative overflow-hidden">
                  <div className="absolute top-0 right-0 p-1.5 bg-gray-900 text-gray-500 text-[8px] font-mono rounded-bl uppercase">
                    Page Content
                  </div>
                  
                  <span className="text-[9px] font-mono text-[#8FB3E0] uppercase tracking-wide font-bold">
                    Clinical Recommendation
                  </span>
                  
                  <p className="text-[11px] text-gray-305 leading-relaxed mt-1 text-left font-sans">
                    {activeTab === 0 && (
                      <span><strong>Clinically proven metrics:</strong> Establish the solid Zone 2 framework of 60-70% max heart rate. This triggers metabolic adaptations, increases insulin sensitivity, and mitigates long-term microvascular plaque risks. Vetted through retrospective studies.</span>
                    )}
                    {activeTab === 1 && (
                      <span><strong>Vascular optimization:</strong> Consume foods rich in potassium (spinach, avocados, white beans) to enhance sodium excretion. Nitric oxide precursor vegetables like beetroots directly enhance arterial compliance and drop blood pressure by 4-8 mmHg in weeks.</span>
                    )}
                    {activeTab === 2 && (
                      <span><strong>Cortisol & Meal alignments:</strong> Do not feed within 2 hours of waking (allow cortisol curves to decline naturally) or within 3 hours of sleep (which clashes with the evening rise of endogenous melatonin and triggers insulin resistance).</span>
                    )}
                    {activeTab === 3 && (
                      <span><strong>Key lab checks:</strong> Track HbA1c to monitor diabetes, high-sensitivity C-reactive protein (hs-CRP) for biological inflammation, and Apolipoprotein B (ApoB) to evaluate small dense particle count. Standard LDL count often underrepresents vascular risk.</span>
                    )}
                  </p>
                </div>
                
              </div>

            </div>

          </div>

        </div>
      </div>
    </section>
  );
}

import React, { useState } from 'react';
import { Play, Flame, Share2, ArrowUpRight, ShieldCheck, Heart, Filter, HelpCircle, Eye, Clock, Calendar } from 'lucide-react';
import { VIDEOS, VIDEO_PILLARS } from '../data';
import { Video } from '../types';
import { motion, AnimatePresence } from 'motion/react';

export default function ContentGrid() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedVideo, setSelectedVideo] = useState<Video | null>(null);

  const filteredVideos = selectedCategory === 'all'
    ? VIDEOS
    : VIDEOS.filter(v => v.category === selectedCategory);

  return (
    <section id="content-insights" className="bg-[#0E0E12] py-20 border-b border-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header Block */}
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-xs font-mono tracking-widest text-[#5865F2] uppercase font-bold px-3 py-1 bg-[#5865F2]/10 rounded-full">
            Clinical Insights Hub
          </span>
          <h2 className="font-display font-black text-3xl sm:text-4xl text-white mt-4 tracking-tight">
            Watch Dr. Nathon's Latest Reels
          </h2>
          <p className="text-gray-400 text-sm sm:text-base mt-2">
            Click on any Reel cards to inspect the clinical evidence, high-yield summaries, and read medically-cited takeaways.
          </p>
        </div>

        {/* Categories / Topic Filters */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-12">
          {VIDEO_PILLARS.map((pillar) => (
            <button
               key={pillar.id}
               onClick={() => setSelectedCategory(pillar.id)}
               className={`px-4 py-2 rounded-full text-xs sm:text-sm font-medium tracking-wide transition-all border cursor-pointer select-none ${
                 selectedCategory === pillar.id
                   ? 'bg-[#5865F2] border-[#5865F2]/40 text-white shadow-lg shadow-[#5865F2]/20'
                   : 'bg-white/5 border-white/5 text-gray-400 hover:border-white/15 hover:bg-white/10 hover:text-white'
               }`}
            >
              {pillar.name}
            </button>
          ))}
        </div>

        {/* Video Reels Vertical Layout Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          <AnimatePresence mode="popLayout">
            {filteredVideos.map((video) => (
              <motion.div
                layout
                key={video.id}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.3 }}
                onClick={() => setSelectedVideo(video)}
                className="relative aspect-[9/16] rounded-2xl overflow-hidden bg-white/5 border border-white/10 group hover:border-[#5865F2] cursor-pointer shadow-xl transition-all backdrop-blur-sm"
              >
                {/* Background Video cover */}
                <img
                  src={video.thumbnailUrl}
                  alt={video.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 filter brightness-95"
                />

                {/* Dark Gradient overlays */}
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent opacity-85"></div>
                <div className="absolute inset-0 bg-gradient-to-t from-[#0E0E12] via-transparent to-transparent opacity-95 group-hover:opacity-100 transition-opacity"></div>

                {/* Engagement / Category Tags on Top card */}
                <div className="absolute top-4 left-4 right-4 flex items-center justify-between">
                  <span className="px-3 py-1 bg-white/5 border border-white/10 rounded-full text-[10px] font-bold uppercase tracking-widest text-[#8FB3E0] backdrop-blur-sm">
                    {VIDEO_PILLARS.find(p => p.id === video.category)?.name.split(' ')[0] || 'Health'}
                  </span>
                  
                  <div className="flex items-center space-x-1 px-2.5 py-1 bg-[#5865F2]/90 rounded-full text-[9px] font-bold font-mono text-white">
                    <Heart className="h-2.5 w-2.5 fill-white" />
                    <span>HIGH YIELD</span>
                  </div>
                </div>

                {/* Center Play Button Floating on hover */}
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="h-14 w-14 rounded-full bg-[#5865F2] text-white flex items-center justify-center shadow-lg shadow-[#5865F2]/30 scale-90 group-hover:scale-100 transition-transform">
                    <Play className="h-6 w-6 fill-white ml-0.5" />
                  </div>
                </div>

                {/* Bottom Title & Meta details */}
                <div className="absolute bottom-0 inset-x-0 p-4 space-y-2 text-left">
                  {/* Title overlay */}
                  <h3 className="font-display font-bold text-sm sm:text-base text-white tracking-tight leading-snug group-hover:text-[#8FB3E0] transition-colors">
                    "{video.title}"
                  </h3>

                  {/* High Yield Fact Micro Teaser */}
                  <p className="text-[11px] text-gray-400 font-sans line-clamp-2 leading-relaxed opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    💡 {video.highYieldFact}
                  </p>

                  {/* Views & Duration Indicators */}
                  <div className="flex items-center justify-between pt-2 border-t border-white/5 text-[10px] font-mono text-gray-500">
                    <span className="flex items-center space-x-1 text-gray-400">
                      <Eye className="h-3 w-3" />
                      <span>{video.views} Views</span>
                    </span>
                    <span className="flex items-center space-x-1">
                      <Clock className="h-3 w-3" />
                      <span>{video.duration}</span>
                    </span>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Video Detail Modal with Medical Citation */}
        <AnimatePresence>
          {selectedVideo && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
              <div aria-hidden="true" className="absolute inset-0 bg-[#0E0E12]/85 backdrop-blur-md" onClick={() => setSelectedVideo(null)}></div>
              
              <motion.div
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                className="relative bg-[#0E0E12]/90 border border-white/10 rounded-2xl max-w-3xl w-full overflow-hidden shadow-2xl flex flex-col md:flex-row z-10 backdrop-blur-xl"
              >
                {/* Modal Left Column: Vertical visual represent */}
                <div className="md:w-5/12 bg-gray-950 relative aspect-[9/16] md:aspect-auto">
                  <img
                    src={selectedVideo.thumbnailUrl}
                    alt={selectedVideo.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/25 to-transparent flex flex-col justify-end p-5">
                    <div className="p-3 bg-white/5 backdrop-blur-md rounded-xl border border-white/10">
                      <p className="text-[10px] font-mono text-[#8FB3E0] uppercase tracking-widest font-bold">Category</p>
                      <p className="text-xs text-white font-medium capitalize mt-0.5">
                        {VIDEO_PILLARS.find(p => p.id === selectedVideo.category)?.name}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Modal Right Column: Medical Evidence Detail */}
                <div className="md:w-7/12 p-6 flex flex-col justify-between space-y-6 bg-[#0E0E12]/40">
                  
                  {/* Top: Header */}
                  <div className="space-y-4 text-left">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-mono tracking-widest text-[#8FB3E0] uppercase font-bold">
                        Medical Research Byte
                      </span>
                      <button
                        onClick={() => setSelectedVideo(null)}
                        className="text-gray-400 hover:text-white p-1 hover:bg-white/5 rounded-lg select-none text-xs"
                      >
                        ✕ Close
                      </button>
                    </div>

                    <h3 className="font-display font-bold text-lg sm:text-xl text-white">
                      {selectedVideo.title}
                    </h3>

                    {/* Highly rigorous summary */}
                    <div className="space-y-3">
                      <span className="inline-block px-2.5 py-1 bg-white/5 border border-white/10 rounded-full text-[10px] font-bold uppercase tracking-widest text-[#8FB3E0]">
                        👨‍⚕️ Clinical High-Yield Fact
                      </span>
                      <p className="text-sm text-gray-300 leading-relaxed bg-white/5 p-4 rounded-xl border border-white/10 font-sans">
                        "{selectedVideo.highYieldFact}"
                      </p>
                    </div>

                    {/* Vetted explanation */}
                    <div className="space-y-2">
                      <h4 className="text-xs font-mono uppercase tracking-wider text-gray-400">Evidence Vetted & Bio-mechanisms</h4>
                      <ul className="space-y-1.5 text-xs text-gray-300">
                        <li className="flex items-start">
                          <span className="text-[#5865F2] mr-2 font-bold">✓</span>
                          <span>Peer-reviewed scientific validation from Harvard/Stanford research indexes.</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-[#5865F2] mr-2 font-bold">✓</span>
                          <span>Mitigates downstream metabolic and circulatory risk vectors when properly integrated.</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-[#5865F2] mr-2 font-bold">✓</span>
                          <span>Practical lifestyle change requiring 0 financial overhead or prescription variables.</span>
                        </li>
                      </ul>
                    </div>
                  </div>

                  {/* Bottom: Actions & original video redirection */}
                  <div className="pt-4 border-t border-white/10 flex flex-col sm:flex-row items-center gap-3">
                    <a
                      href={selectedVideo.videoUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full sm:flex-1 py-2.5 bg-[#5865F2] hover:bg-[#4752C4] text-white text-xs font-bold text-center rounded-xl transition-all flex items-center justify-center space-x-2"
                    >
                      <span>Watch Reel on Instagram</span>
                      <ArrowUpRight className="h-3.5 w-3.5" />
                    </a>

                    <button
                      onClick={() => setSelectedVideo(null)}
                      className="w-full sm:w-auto px-4 py-2.5 bg-white/5 hover:bg-white/10 text-gray-300 border border-white/10 text-xs font-semibold rounded-xl text-center cursor-pointer"
                    >
                      Dismiss
                    </button>
                  </div>

                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

      </div>
    </section>
  );
}

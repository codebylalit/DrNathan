import React, { useState } from 'react';
import { Award, Building2, Eye, Users, ChevronLeft, ChevronRight, Quote, Plus } from 'lucide-react';
import { PRESS_MENTIONS } from '../data';
import { motion, AnimatePresence } from 'motion/react';

export default function CredibilityBar() {
  const [activePressIdx, setActivePressIdx] = useState(0);

  const prevPress = () => {
    setActivePressIdx((prev) => (prev === 0 ? PRESS_MENTIONS.length - 1 : prev - 1));
  };

  const nextPress = () => {
    setActivePressIdx((prev) => (prev === PRESS_MENTIONS.length - 1 ? 0 : prev + 1));
  };

  return (
    <div className="bg-white/5 border-y border-white/5 py-12 relative backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Core Institutional & Subscriber Stat Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6 text-center">
          
          <div className="flex flex-col items-center p-5 bg-white/5 border border-white/10 rounded-2xl backdrop-blur-xl transition-colors hover:bg-white/10">
            <div className="mb-2 p-1.5 bg-[#A51C30]/10 rounded border border-[#A51C30]/20 text-[#A51C30] flex items-center justify-center">
              <Award className="h-5 w-5" />
            </div>
            <span className="font-display font-black text-2xl lg:text-3xl text-white tracking-tight">Harvard MD</span>
            <span className="text-xs text-gray-400 mt-1 uppercase tracking-wider font-mono">Academic Doctor</span>
          </div>

          <div className="flex flex-col items-center p-5 bg-white/5 border border-white/10 rounded-2xl backdrop-blur-xl transition-colors hover:bg-white/10">
            <div className="mb-2 p-1.5 bg-[#8C1515]/10 rounded border border-[#8C1515]/20 text-[#8C1515] flex items-center justify-center">
              <Building2 className="h-5 w-5" />
            </div>
            <span className="font-display font-black text-2xl lg:text-3xl text-white tracking-tight">Stanford</span>
            <span className="text-xs text-gray-400 mt-1 uppercase tracking-wider font-mono">Medical Resident</span>
          </div>

          <div className="flex flex-col items-center p-5 bg-white/5 border border-white/10 rounded-2xl backdrop-blur-xl transition-colors hover:bg-white/10">
            <div className="mb-2 p-1.5 bg-[#5865F2]/10 rounded border border-[#5865F2]/20 text-[#8FB3E0] flex items-center justify-center">
              <Users className="h-5 w-5" />
            </div>
            <span className="font-display font-black text-2xl lg:text-3xl text-white tracking-tight">1.5 Million+</span>
            <span className="text-xs text-gray-400 mt-1 uppercase tracking-wider font-mono">Total Followers</span>
          </div>

          <div className="flex flex-col items-center p-5 bg-white/5 border border-white/10 rounded-2xl backdrop-blur-xl transition-colors hover:bg-white/10">
            <div className="mb-2 p-1.5 bg-emerald-500/10 rounded border border-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <Eye className="h-5 w-5" />
            </div>
            <span className="font-display font-black text-2xl lg:text-3xl text-white tracking-tight">50 Million+</span>
            <span className="text-xs text-gray-400 mt-1 uppercase tracking-wider font-mono">Annual Views</span>
          </div>

        </div>

        {/* Media & Press Mentions Quote Box */}
        <div className="mt-12 pt-10 border-t border-white/5">
          <div className="text-center mb-6">
            <span className="text-[10px] font-mono tracking-widest text-[#8FB3E0] uppercase font-bold">
              Institutional Trust & Media Mentions
            </span>
            <h2 className="text-xl font-display font-bold text-white mt-1">
              As Featured & Cited In
            </h2>
          </div>

          <div className="max-w-4xl mx-auto bg-white/5 border border-white/10 rounded-2xl p-6 sm:p-8 relative overflow-hidden backdrop-blur-xl shadow-lg">
            <div className="absolute top-4 left-6 text-gray-850">
              <Quote className="h-10 w-10 opacity-30 transform -scale-x-100" />
            </div>
            
            <AnimatePresence mode="wait">
              <motion.div
                key={activePressIdx}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.3 }}
                className="flex flex-col items-center text-center space-y-4"
              >
                <p className="text-sm sm:text-base text-gray-300 italic max-w-2xl leading-relaxed relative z-10">
                  "{PRESS_MENTIONS[activePressIdx].quote}"
                </p>
                
                <div>
                  <span className={`text-sm font-display font-bold font-mono tracking-wider ${PRESS_MENTIONS[activePressIdx].logoColor}`}>
                    {PRESS_MENTIONS[activePressIdx].textLogo || PRESS_MENTIONS[activePressIdx].outlet}
                  </span>
                  <p className="text-[11px] text-gray-500 mt-0.5">
                    {PRESS_MENTIONS[activePressIdx].outlet}
                  </p>
                </div>
              </motion.div>
            </AnimatePresence>

            {/* Slider Controls */}
            <div className="flex items-center justify-center space-x-3 mt-6">
              <button
                onClick={prevPress}
                className="p-1 px-2 rounded-lg bg-gray-900 border border-gray-800 hover:border-[#5865F2] hover:text-[#5865F2] text-gray-400 transition-all cursor-pointer"
                title="Previous quote"
              >
                <ChevronLeft className="h-4 w-4" />
              </button>
              
              <div className="flex space-x-1.5">
                {PRESS_MENTIONS.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActivePressIdx(idx)}
                    className={`h-2 rounded-full transition-all cursor-pointer ${
                      activePressIdx === idx ? 'w-6 bg-[#5865F2]' : 'w-2 bg-gray-800'
                    }`}
                  />
                ))}
              </div>

              <button
                onClick={nextPress}
                className="p-1 px-2 rounded-lg bg-gray-900 border border-gray-800 hover:border-[#5865F2] hover:text-[#5865F2] text-gray-400 transition-all cursor-pointer"
                title="Next quote"
              >
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
